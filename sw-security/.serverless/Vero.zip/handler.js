import { handleRequest } from "./build/server/index.js"; // ES6 import 방식

export const handler = async (event, context) => {
  const request = new Request(event.url, {
    method: event.httpMethod,
    headers: event.headers,
    body: event.body,
  });

  try {
    const response = await handleRequest(
      request, // request 객체
      event.statusCode, // 상태 코드
      event.headers, // HTTP 헤더
      {}, // Remix의 remixContext
      {} // 추가적인 loadContext
    );
    return response;
  } catch (error) {
    console.error("Error handling request:", error);
    return {
      statusCode: 500,
      body: "Internal Server Error",
    };
  }
};
