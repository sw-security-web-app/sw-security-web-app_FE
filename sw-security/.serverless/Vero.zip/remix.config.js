module.exports = {
  target: "serverless",
};
